### Hexlet tests and linter status:
[![Actions Status](https://github.com/Gaben74/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Gaben74/python-project-49/actions)

<a href="https://codeclimate.com/github/Gaben74/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/bf830954ff51ca9d5eb9/maintainability" /></a>